Topological SAT Solver Project
This will contain all project files.