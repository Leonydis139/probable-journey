# Full Research Package

- paper/: LaTeX source (12 pages), response_to_reviewers, slides
- src/: solver implementation
- data/: benchmark CSV
