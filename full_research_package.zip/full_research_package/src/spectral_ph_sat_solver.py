# Complete solver implementation
